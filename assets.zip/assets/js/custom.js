//This Code working is One click copy button
// const btn_copy = document.querySelector(".btn_copy");
// const code_copy = document.querySelector(".code_copy");
// window.navigator.clipboard.writeText(code_copy.innerText);
// btn_copy.onclick = function(){
//     window.navigator.clipboard.writeText(code_copy.innerText);
//     alert("Copy Successfully");
// }
